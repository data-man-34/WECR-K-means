"""
Some Global Settings.
"""

default_eval_path = 'Results/Eval/'
default_constraints_folder = 'Constraints/'
default_library_path = 'Results/'
default_constraints_postfix = ['constraints_quarter_n',
                               'constraints_half_n',
                               'constraints_n',
                               'constraints_onehalf_n',
                               'constraints_2n']
