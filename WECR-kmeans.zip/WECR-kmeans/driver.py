import member_generation.library_generation as lg
import utils.io_func as io_func
import utils.exp_datasets as exd
import evaluation.Metrics as Metrics
import constrained_methods.generate_constraints_link as gcl
import ensemble.ensemble_wrapper as ew
import evaluation.comparision_methods as ed
import deal_constrains
 
_postfix = ['constrains_n_1', 'diff_n_2', 'diff_n_3', 'diff_n_4', 'diff_n_5']
_noise_postfix = ['noise_n_1', 'noise_n_2', 'noise_n_3', 'noise_n_4', 'noise_n_5']

"""
========================================================================================================================
Generate Basic Library
========================================================================================================================
"""
"""
generate basic library
(double-random kmeans)
"""
#lg.generate_libs_by_sampling_rate('Iris', 100)
lg.generate_libs_by_sampling_rate('OPTDIGITS', 1000)
lg.generate_libs_by_sampling_rate('Segmentation', 1000)
lg.generate_libs_by_sampling_rate('ISOLET', 1000)
lg.generate_libs_by_sampling_rate('MNIST4000', 1000)
lg.generate_libs_by_sampling_rate('COIL20', 1000)
lg.generate_libs_by_sampling_rate('Prostate', 1000)
lg.generate_libs_by_sampling_rate('SRBCT', 1000)
lg.generate_libs_by_sampling_rate('LungCancer', 1000)
lg.generate_libs_by_sampling_rate('Leukemia1', 1000)
lg.generate_libs_by_sampling_rate('Leukemia2', 1000)
#lg.generate_libs_by_sampling_rate('TOX', 100)


"""
========================================================================================================================
Generate Constraints
========================================================================================================================
"""
"""
generate constraints [part1: different amount of constraints]
#"""
gcl.generate_diff_amount_constraints_wrapper('OPTDIGITS')
gcl.generate_diff_amount_constraints_wrapper('Segmentation')
gcl.generate_diff_amount_constraints_wrapper('ISOLET')
gcl.generate_diff_amount_constraints_wrapper('MNIST4000')
gcl.generate_diff_amount_constraints_wrapper('COIL20')
gcl.generate_diff_amount_constraints_wrapper('Prostate')
gcl.generate_diff_amount_constraints_wrapper('SRBCT')
gcl.generate_diff_amount_constraints_wrapper('LungCancer')
gcl.generate_diff_amount_constraints_wrapper('Leukemia2')
##gcl.generate_diff_amount_constraints_wrapper('TOX')
gcl.generate_diff_amount_constraints_wrapper('Leukemia1')

#deal_constrains.ma()

#"""
#generate constraints [part2: different constraints in same amount]
#"""
gcl.generate_diff_constraints_wrapper('OPTDIGITS')
gcl.generate_diff_constraints_wrapper('Segmentation')
gcl.generate_diff_constraints_wrapper('ISOLET')
gcl.generate_diff_constraints_wrapper('MNIST4000')
gcl.generate_diff_constraints_wrapper('COIL20')
gcl.generate_diff_constraints_wrapper('Prostate')
gcl.generate_diff_constraints_wrapper('SRBCT')
gcl.generate_diff_constraints_wrapper('LungCancer')
gcl.generate_diff_constraints_wrapper('Leukemia2')
gcl.generate_diff_constraints_wrapper('Leukemia1')
#gcl.generate_diff_constraints_wrapper('TOX')
##
##"""
##generate constraints [part3: constraints with different level of noise constraints]
##"""
gcl.generate_noise_constraints_wrapper('OPTDIGITS')
gcl.generate_noise_constraints_wrapper('Segmentation')
gcl.generate_noise_constraints_wrapper('ISOLET')
gcl.generate_noise_constraints_wrapper('MNIST4000')
gcl.generate_noise_constraints_wrapper('COIL20')
gcl.generate_noise_constraints_wrapper('Prostate')
gcl.generate_noise_constraints_wrapper('SRBCT')
gcl.generate_noise_constraints_wrapper('LungCancer')
gcl.generate_noise_constraints_wrapper('Leukemia2')
gcl.generate_noise_constraints_wrapper('Leukemia1')
#gcl.generate_noise_constraints_wrapper('TOX')
##
#"""
#========================================================================================================================
#Semi-supervised Library Generation
#========================================================================================================================
#"""
#"""
#library generation (E2CP and cop-kmeans)
#[part1: different amount of constraints]
##"""
lg.generate_libs_by_constraints('OPTDIGITS', 1000)
lg.generate_libs_by_constraints('Segmentation', 1000)
lg.generate_libs_by_constraints('ISOLET', 1000)
lg.generate_libs_by_constraints('MNIST4000', 1000)
lg.generate_libs_by_constraints('COIL20', 1000)
lg.generate_libs_by_constraints('Prostate', 1000)
lg.generate_libs_by_constraints('SRBCT', 1000)
lg.generate_libs_by_constraints('LungCancer', 1000)
lg.generate_libs_by_constraints('Leukemia2', 1000)
lg.generate_libs_by_constraints('Leukemia1', 1000)
##lg.generate_libs_by_constraints('TOX', 100)
# 
lg.generate_libs_by_constraints('OPTDIGITS', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('Segmentation', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('ISOLET', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('MNIST4000', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('COIL20', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('Prostate', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('SRBCT', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('LungCancer', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('Leukemia2', 1000, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('Leukemia1', 1000, member_method='Cop_KMeans')
#lg.generate_libs_by_constraints('TOX', 100,member_method='Cop_KMeans')
#
#
#"""
#library generation (E2CP and cop-kmeans)
#[part2: different constraints in same amount]
#"""
lg.generate_libs_by_constraints('OPTDIGITS', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('Segmentation', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('ISOLET', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('MNIST4000', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('COIL20', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('Prostate', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('SRBCT', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('LungCancer', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('Leukemia2', 1000, postfixes=_postfix)
lg.generate_libs_by_constraints('Leukemia1', 1000, postfixes=_postfix)
#lg.generate_libs_by_constraints('TOX', 100, postfixes=_postfix)

lg.generate_libs_by_constraints('OPTDIGITS', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('Segmentation', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('ISOLET', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('MNIST4000', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('COIL20', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('Prostate', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('SRBCT', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('LungCancer', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('Leukemia2', 1000, member_method='Cop_KMeans', postfixes=_postfix)
lg.generate_libs_by_constraints('Leukemia1', 1000, member_method='Cop_KMeans', postfixes=_postfix)
#lg.generate_libs_by_constraints('TOX', 100,member_method='Cop_KMeans', postfixes=_postfix)
##
##"""
##library generation (E2CP and cop-kmeans)
##[part3: constraints with different level of noise constraints]
###"""
lg.generate_libs_by_constraints('Prostate', 1000, postfixes=_noise_postfix)
lg.generate_libs_by_constraints('SRBCT', 1000,  postfixes=_noise_postfix)
lg.generate_libs_by_constraints('LungCancer', 1000,  postfixes=_noise_postfix)
lg.generate_libs_by_constraints('Leukemia2', 1000,  postfixes=_noise_postfix)
lg.generate_libs_by_constraints('Leukemia1', 1000,  postfixes=_noise_postfix)
lg.generate_libs_by_constraints('OPTDIGITS', 1000, postfixes=_noise_postfix)
lg.generate_libs_by_constraints('Segmentation', 1000,  postfixes=_noise_postfix)
lg.generate_libs_by_constraints('ISOLET', 1000,  postfixes=_noise_postfix)
lg.generate_libs_by_constraints('MNIST4000', 1000,  postfixes=_noise_postfix)
lg.generate_libs_by_constraints('COIL20', 1000,  postfixes=_noise_postfix)
#lg.generate_libs_by_constraints('TOX', 100,  postfixes=_noise_postfix)
###

lg.generate_libs_by_constraints('Prostate', 1000, postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('SRBCT', 1000,  postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('LungCancer', 1000,  postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('Leukemia2', 1000,  postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('Leukemia1', 1000,  postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('OPTDIGITS', 1000, postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('Segmentation', 1000,  postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('ISOLET', 1000,  postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('MNIST4000', 1000,  postfixes=_noise_postfix, member_method='Cop_KMeans')
lg.generate_libs_by_constraints('COIL20', 1000,  postfixes=_noise_postfix, member_method='Cop_KMeans')
#####
##lg.generate_libs_by_constraints('TOX', 100,  postfixes=_noise_postfix, member_method='Cop_KMeans')
##

"""
===========================================================================================================
new experiments, 12th Dec, 2017.
updates: new formula for calculating weights (g_gamma introduced)
12.27 modified: internals included
===========================================================================================================
"""
"""
experiment
[part1: different amount of constraints]
"""
#deal_constrains.ma()

ew.do_ensemble_different_constraints_new_exp('MNIST4000_50-100_0.7_0.9_1000_FSRSNC_pure')
ew.do_ensemble_different_constraints_new_exp('OPTDIGITS_50-100_0.7_0.9_1000_FSRSNC_pure')
ew.do_ensemble_different_constraints_new_exp('Segmentation_35-70_0.5_0.8_1000_FSRSNC_pure')
ew.do_ensemble_different_constraints_new_exp('COIL20_100-200_0.9_0.2_1000_FSRSNC_pure')
ew.do_ensemble_different_constraints_new_exp('ISOLET_130-260_0.6_0.4_1000_FSRSNC_pure')
ew.do_ensemble_different_constraints_new_exp('SRBCT_20-40_0.6_0.6_1000_FSRSNC_pure')
####scaled和not_scaled都跑一下，True和False
ew.do_ensemble_different_constraints_new_exp('Prostate_10-20_0.8_0.3_1000_FSRSNC_pure')
ew.do_ensemble_different_constraints_new_exp('LungCancer_20-40_0.9_0.3_1000_FSRSNC_pure')
ew.do_ensemble_different_constraints_new_exp('Leukemia1_15-30_0.7_0.2_1000_FSRSNC_pure')
ew.do_ensemble_different_constraints_new_exp('Leukemia2_15-30_0.6_0.5_1000_FSRSNC_pure')
#ew.do_ensemble_different_constraints_new_exp('colon_10-20_0.9_0.3_100_FSRSNC_pure')
#ew.do_ensemble_different_constraints_new_exp('TOX_20-40_0.6_0.8_100_FSRSNC_pure')
###
"""
experiment
[part2: different constraints in same amount]
#"""
ew.do_ensemble_different_constraints_new_exp('MNIST4000_50-100_0.7_0.9_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('OPTDIGITS_50-100_0.7_0.9_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('Segmentation_35-70_0.5_0.8_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('COIL20_100-200_0.9_0.2_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('ISOLET_130-260_0.6_0.4_100_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('SRBCT_20-40_0.6_0.6_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('Prostate_10-20_0.8_0.3_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('LungCancer_20-40_0.9_0.3_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('Leukemia1_15-30_0.7_0.2_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
ew.do_ensemble_different_constraints_new_exp('Leukemia2_15-30_0.6_0.5_1000_FSRSNC_pure', True, constraints_files_postfix=_postfix)
#ew.do_ensemble_different_constraints_new_exp('TOX_20-40_0.6_0.8_100_FSRSNC_pure',True, constraints_files_postfix=_postfix)
##
#"""
#experiment
#[part3: constraints with different level of noise constraints]
#"""
ew.do_ensemble_different_constraints_new_exp('MNIST4000_50-100_0.7_0.9_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('OPTDIGITS_50-100_0.7_0.9_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('Segmentation_35-70_0.5_0.8_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('COIL20_100-200_0.9_0.2_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('ISOLET_130-260_0.6_0.4_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('SRBCT_20-40_0.6_0.6_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('Prostate_10-20_0.8_0.3_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('LungCancer_20-40_0.9_0.3_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('Leukemia1_15-30_0.7_0.2_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)

ew.do_ensemble_different_constraints_new_exp('Leukemia2_15-30_0.6_0.5_1000_FSRSNC_pure', True, constraints_files_postfix=_noise_postfix)
#ew.do_ensemble_different_constraints_new_exp('TOX_20-40_0.6_0.8_100_FSRSNC_pure',True, constraints_files_postfix=_noise_postfix)
##
#
#"""
#========================================================================================================================
#Comparison Methods
#========================================================================================================================
#"""
#
#"""
#comparison methods [part1: different amount of constraints]
#"""
ed.comparison_methods('OPTDIGITS')
ed.comparison_methods('Segmentation')
ed.comparison_methods('ISOLET')
ed.comparison_methods('MNIST4000')
ed.comparison_methods('COIL20')
ed.comparison_methods('Prostate')
ed.comparison_methods('SRBCT')
ed.comparison_methods('LungCancer')
ed.comparison_methods('Leukemia2')
ed.comparison_methods('Leukemia1')
##ed.comparison_methods('TOX')
##
###"""
###comparison methods [part2: different constraints in same amount]
##"""
ed.comparison_methods('OPTDIGITS', constraints_files=_postfix)
ed.comparison_methods('Segmentation', constraints_files=_postfix)
ed.comparison_methods('ISOLET', constraints_files=_postfix)
ed.comparison_methods('MNIST4000', constraints_files=_postfix)
ed.comparison_methods('COIL20', constraints_files=_postfix)
ed.comparison_methods('Prostate', constraints_files=_postfix)
ed.comparison_methods('SRBCT', constraints_files=_postfix)
ed.comparison_methods('LungCancer', constraints_files=_postfix)
ed.comparison_methods('Leukemia2', constraints_files=_postfix)
ed.comparison_methods('Leukemia1', constraints_files=_postfix)
#ed.comparison_methods('TOX', constraints_files=_postfix)
##
##"""
##comparison methods [part3: constraints with different level of noise constraints]
#"""
ed.comparison_methods('OPTDIGITS', constraints_files=_noise_postfix)
ed.comparison_methods('Segmentation', constraints_files=_noise_postfix)
ed.comparison_methods('ISOLET', constraints_files=_noise_postfix)
ed.comparison_methods('MNIST4000', constraints_files=_noise_postfix)
ed.comparison_methods('COIL20', constraints_files=_noise_postfix)
ed.comparison_methods('Prostate', constraints_files=_noise_postfix)
ed.comparison_methods('SRBCT', constraints_files=_noise_postfix)
ed.comparison_methods('LungCancer', constraints_files=_noise_postfix)
ed.comparison_methods('Leukemia2', constraints_files=_noise_postfix)
ed.comparison_methods('Leukemia1', constraints_files=_noise_postfix)
#ed.comparison_methods('TOX', constraints_files=_noise_postfix)
